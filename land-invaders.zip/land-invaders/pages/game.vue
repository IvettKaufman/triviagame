<template>
<div class="game">
  main game here
</div>
</template>
